/**
 * Created by:
 * Class: PWA1
 * Goal: Goal9
 */

console.log("start canvas");

(function(){
    

})();